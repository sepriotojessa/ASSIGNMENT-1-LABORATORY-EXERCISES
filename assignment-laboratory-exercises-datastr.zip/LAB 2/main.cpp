// SEPRIOTO, JESSA S.
// IT2J
// LABORATORY EXERCISE #2

#include <iostream>
using namespace std;

int main() {
    int num;

    cout << "Enter a number: ";
    cin >> num;

    if (num > 0) {
        cout << "The number is positive." << endl;
    }

    return 0;
}
