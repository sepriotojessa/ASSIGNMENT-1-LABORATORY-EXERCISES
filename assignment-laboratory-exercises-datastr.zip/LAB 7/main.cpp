// SEPRIOTO, JESSA S.
// IT2J
// LABORATORY EXERCISE #7 

#include <iostream>
using namespace std;

int main() {
    int grade, courseCode;

    cout << "Enter grade (0-100): ";
    cin >> grade;

    cout << "Enter course code (1-3): ";
    cin >> courseCode;

    if (grade >= 75 && grade <= 100) {
        cout << "\nResult: Pass" << endl;
    } else if (grade >= 0 && grade < 75) {
        cout << "\nResult: Fail" << endl;
    } else {
        cout << "\nInvalid grade input." << endl;
        return 0; 
    }
    switch (courseCode) {
        case 1:
            cout << "Course: Programming Fundamentals" << endl;
            break;
        case 2:
            cout << "Course: Data Structures" << endl;
            break;
        case 3:
            cout << "Course: Database Management" << endl;
            break;
        default:
            cout << "Invalid course code." << endl;
            break;
    }

    return 0;
}
